async page => {
  const root = 'C:/Users/kanazxz/Desktop/SunkarSABAQ';
  const base = 'http://127.0.0.1:5173';
  const results = [];
  const failures = [];
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  const check = (condition, message) => {
    results.push({ check: message, passed: Boolean(condition) });
    if (!condition) failures.push(message);
  };

  for (const screen of ['overview', 'analytics', 'budget']) {
    await page.setViewportSize({ width: 360, height: 700 });
    await page.goto(`${base}/landing-ersinbaev/previews/${screen}.html`);
    await page.screenshot({ path: `${root}/landing-ersinbaev/assets/${screen}.png` });
  }

  for (const width of [320, 375, 600, 601, 768, 1023, 1024, 1280, 1920]) {
    await page.setViewportSize({ width, height: 900 });
    await page.goto(`${base}/landing-ersinbaev/`);
    await page.locator('#screens').scrollIntoViewIfNeeded();
    await page.waitForFunction(() => [...document.images].every(img => img.complete && img.naturalWidth > 0));
    await page.evaluate(() => scrollTo(0, 0));
    const layout = await page.evaluate(() => ({
      scroll: document.documentElement.scrollWidth,
      width: innerWidth,
      columns: getComputedStyle(document.querySelector('.feature-grid')).gridTemplateColumns.split(' ').length,
      navDirection: getComputedStyle(document.querySelector('.header nav')).flexDirection,
      hasNesting: getComputedStyle(document.querySelector('.feature h3')).marginTop,
      links: [...document.querySelectorAll('a[href^="#"]')].every(a => a.hash === '' || Boolean(document.querySelector(a.hash))),
    }));
    check(layout.scroll <= layout.width, `Landing: no horizontal overflow at ${width}px (${layout.scroll})`);
    check(layout.columns === (width <= 600 ? 1 : width < 1024 ? 2 : 3), `Landing: correct feature columns at ${width}px`);
    check(layout.links, `Landing: section anchors work at ${width}px`);
    if (width <= 600) check(layout.navDirection === 'column', `Landing: vertical mobile navigation at ${width}px`);
    if ([375, 768, 1280].includes(width)) {
      await page.screenshot({ path: `${root}/landing-ersinbaev/screenshots/${width}.png`, fullPage: true });
    }
  }

  // Verify the download is a real served ZIP, rather than a dead store link.
  const response = await page.request.get(`${base}/landing-ersinbaev/downloads/qarjy-web-demo.zip`);
  check(response.ok(), 'Landing: downloadable web demo ZIP returns HTTP 200');
  await page.setViewportSize({ width: 1280, height: 900 });
  await page.goto(`${base}/dom-store-ersinbaev/`);
  check(await page.locator('.empty').isVisible(), 'DOM: empty state visible');
  await page.getByRole('button', { name: 'Добавить в список' }).click();
  check(await page.locator('#name-error').textContent() !== '', 'DOM: empty name has an inline error');
  check(await page.locator('#price-error').textContent() !== '', 'DOM: empty price has an inline error');
  await page.locator('#name').fill('Молоко');
  await page.locator('#price').fill('0');
  await page.locator('#qty').fill('-1');
  await page.getByRole('button', { name: 'Добавить в список' }).click();
  check(await page.locator('#price-error').textContent() !== '', 'DOM: zero price is rejected');
  check(await page.locator('#qty-error').textContent() !== '', 'DOM: negative quantity is rejected');
  await page.locator('#qty').fill('1.5');
  await page.getByRole('button', { name: 'Добавить в список' }).click();
  check(await page.locator('#qty-error').textContent() !== '', 'DOM: fractional quantity is rejected');
  await page.locator('#qty').fill('');
  await page.getByRole('button', { name: 'Добавить в список' }).click();
  check(await page.locator('#qty-error').textContent() !== '', 'DOM: missing quantity is rejected');
  await page.locator('#price').fill('550');
  await page.locator('#qty').fill('2');
  await page.getByRole('button', { name: 'Добавить в список' }).click();
  check(await page.locator('.product').count() === 1, 'DOM: form adds a product');
  check((await page.locator('#total').textContent()).replace(/\s/g, '').includes('1100'), 'DOM: total is price × quantity');
  await page.getByRole('button', { name: 'Увеличить количество: Молоко', exact: true }).click();
  check((await page.locator('#total').textContent()).replace(/\s/g, '').includes('1650'), 'DOM: delegated increase recalculates total');
  await page.getByRole('button', { name: 'Уменьшить количество: Молоко', exact: true }).click();
  check((await page.locator('#total').textContent()).replace(/\s/g, '').includes('1100'), 'DOM: delegated decrease recalculates total');
  await page.locator('#name').fill('Молоко'); await page.locator('#price').fill('1');
  await page.getByRole('button', { name: 'Добавить в список' }).click();
  check(await page.locator('.product').count() === 1 && await page.locator('#name-error').textContent() !== '', 'DOM: duplicate product is rejected');
  await page.locator('#name').fill('<img src=x onerror=alert(1)>');
  await page.locator('#price').fill('0.10'); await page.locator('#qty').fill('3');
  await page.getByRole('button', { name: 'Добавить в список' }).click();
  check(await page.locator('.product img').count() === 0 && (await page.locator('.product h3').allTextContents()).includes('<img src=x onerror=alert(1)>'), 'DOM: input rendered as text, not injected HTML');
  await page.getByRole('button', { name: 'Удалить: <img src=x onerror=alert(1)>', exact: true }).click();
  await page.getByRole('button', { name: 'Удалить: Молоко', exact: true }).click();
  check(await page.locator('.empty').isVisible(), 'DOM: deleting final product restores empty state');
  check((await page.locator('#total').textContent()).replace(/\s/g, '').startsWith('0'), 'DOM: total returns to zero');
  for (const [name, price, qty] of [['Молоко', '550', '2'], ['Хлеб цельнозерновой', '420', '1'], ['Яблоки', '850', '3']]) {
    await page.locator('#name').fill(name); await page.locator('#price').fill(price); await page.locator('#qty').fill(qty);
    await page.getByRole('button', { name: 'Добавить в список' }).click();
  }
  for (const width of [320, 375, 600, 768, 1024, 1280]) {
    await page.setViewportSize({ width, height: 900 });
    const hasOverflow = await page.evaluate(() => document.documentElement.scrollWidth > innerWidth);
    check(!hasOverflow, `DOM: no horizontal overflow at ${width}px`);
    if ([375, 768, 1280].includes(width)) await page.screenshot({ path: `${root}/dom-store-ersinbaev/screenshots/${width}.png`, fullPage: true });
  }
  await page.reload();
  check(await page.locator('.empty').isVisible(), 'DOM: documented session reset after reload');
  await page.goto(`file:///${root}/dom-store-ersinbaev/index.html`);
  await page.locator('#name').fill('Локальный товар'); await page.locator('#price').fill('100');
  await page.getByRole('button', { name: 'Добавить в список' }).click();
  check(await page.locator('.product').count() === 1, 'DOM: index.html works directly via file:// without a server');
  await page.setViewportSize({ width: 1180, height: 900 });
  await page.goto(`${base}/js-core-ersinbaev/screenshots/test-report.html`);
  await page.screenshot({ path: `${root}/js-core-ersinbaev/screenshots/tests.png`, fullPage: true });
  check(errors.length === 0, `No JavaScript runtime errors (${errors.length})`);
  return { passed: results.filter(r => r.passed).length, failed: failures.length, failures, errors, results };
}
