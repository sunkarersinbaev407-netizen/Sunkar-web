"""Prepare original prototype screens and a report from actual Vitest output."""
from pathlib import Path
import json
import html

root = Path(__file__).resolve().parent.parent
landing = root / 'landing-ersinbaev'
source = (landing / 'index.html').read_text(encoding='utf-8')
phone = source.split('<div class="phone"', 1)[1].split('<div class="floating-note">', 1)[0]
phone = '<div class="phone"' + phone
# Remove the closing hero-visual div left after extracting the phone.
phone = phone.rsplit('</div>', 1)[0]
base = '''<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Qarjy — макет интерфейса</title><link rel="icon" href="../assets/icon.svg"><link rel="stylesheet" href="../style.css"><style>body{background:#fafbf8;width:360px;height:700px;overflow:hidden}.phone{border:0;border-radius:0;box-shadow:none;transform:none;width:360px;height:700px;padding:20px 24px;font-size:14px}.phone-top{font-size:12px;padding-bottom:30px}.app-greeting{font-size:16px;margin-bottom:22px}.avatar{width:36px;height:36px}.balance{padding:25px 20px}.balance strong{font-size:38px}.balance small{font-size:12px}.balance-note{font-size:11px}.app-section-title{font-size:13px;margin-block:24px 16px}.app-section-title>span{font-size:11px}.mini-stats span{font-size:10px}.mini-stats strong{font-size:14px}.mini-stats>div{padding:17px 13px}.transaction{padding-block:11px}.transaction strong,.transaction b{font-size:12px}.transaction small{font-size:10px}.tx-icon{width:36px;height:36px}.app-nav{padding-top:18px}.app-nav small{font-size:10px}.app-nav>span{font-size:22px}.app-nav .add-expense{width:38px;height:38px}.chart{width:190px;height:190px;background:conic-gradient(#21473b 0 46%,#c6ed9b 46% 75%,#d5c3e8 75% 90%,#e9d7ad 90%);border-radius:50%;margin:30px auto;display:grid;place-items:center}.chart>div{background:#fafbf8;width:140px;height:140px;border-radius:50%;display:grid;place-content:center;text-align:center;gap:8px}.chart strong{font-size:24px}.chart small{font-size:11px;color:#68746e}.category-row{display:flex;justify-content:space-between;border-bottom:1px solid #e2e7dc;padding:17px 0;font-size:13px}.budget-card{border:1px solid #dfe5db;border-radius:17px;padding:22px;margin-top:24px}.budget-card h3{font-size:18px;margin:15px 0}.budget-card p{font-size:12px;color:#68746e}.budget-card progress{width:100%;margin:18px 0;accent-color:#21473b}.budget-meta{display:flex;justify-content:space-between;font-size:12px}.goal-emoji{font-size:26px}.hint{font-size:11px;color:#68746e;line-height:1.7;margin-top:24px}.screen-heading{font-size:26px;letter-spacing:-1px;margin:14px 0 8px}</style></head><body>CONTENT</body></html>'''
(landing / 'previews/overview.html').write_text(base.replace('CONTENT', phone), encoding='utf-8')
top = '<div class="phone"><div class="phone-top"><span>9:41</span><span class="island"></span><span>••• ▰</span></div>'
bottom = '<div class="app-nav"><span>⌂<small>Обзор</small></span><span>◷<small>История</small></span><span class="add-expense">+</span><span class="active">◴<small>Аналитика</small></span></div></div>'
analytics = top + '''<h1 class="screen-heading">Куда уходят деньги?</h1><p style="color:#68746e;font-size:12px">Октябрь 2026 · Пример данных</p><div class="chart"><div><small>Всего расходов</small><strong>125 500 ₸</strong></div></div><div class="app-section-title"><strong>По категориям</strong><span>За месяц ⌄</span></div><div class="category-row"><span>▧ Покупки</span><strong>57 730 ₸</strong></div><div class="category-row"><span>☕ Кафе</span><strong>36 395 ₸</strong></div><div class="category-row"><span>↗ Транспорт</span><strong>18 825 ₸</strong></div><div class="category-row"><span>✳ Другое</span><strong>12 550 ₸</strong></div>''' + bottom
budget = top + '''<h1 class="screen-heading">Место для мечты.</h1><p style="color:#68746e;font-size:12px">Твой план на октябрь</p><div class="balance" style="margin-top:25px"><small>Бюджет месяца</small><strong>180 000 <span>₸</span></strong><span class="balance-note">Осталось 54 500 ₸ из бюджета</span></div><div class="budget-card"><span class="goal-emoji">☀</span><h3>На путешествие</h3><p>Пусть следующий отпуск будет ближе.</p><progress value="60" max="100">60%</progress><div class="budget-meta"><strong>90 000 ₸</strong><span>из 150 000 ₸</span></div></div><p class="hint">Учебный макет: суммы и прогресс показаны для примера. Реальных банковских операций здесь нет.</p>''' + bottom
for name, content in [('analytics', analytics), ('budget', budget)]:
    (landing / f'previews/{name}.html').write_text(base.replace('CONTENT', content), encoding='utf-8')

result_path = root / 'js-core-ersinbaev/screenshots/test-results.json'
if result_path.exists():
    results = json.loads(result_path.read_text(encoding='utf-8'))
    lines = []
    for suite in results['testResults']:
        lines.append(f'<h2>{html.escape(Path(suite["name"]).name)}</h2>')
        for test in suite['assertionResults']:
            lines.append(f'<p class="{test["status"]}">{"✓" if test["status"] == "passed" else "✕"} {html.escape(test["fullName"])}</p>')
    report = '''<!doctype html><html lang="ru"><head><meta charset="utf-8"><title>Vitest — результаты тестов</title><style>body{font:15px/1.6 Consolas,monospace;background:#14231e;color:#e2eddc;padding:36px;max-width:1050px;margin:auto}h1{font-size:30px;color:#c6ed9b}h2{font-size:19px;margin-top:32px}p{margin:7px 0}.passed{color:#b9df99}.failed{color:#ffaba0}.meta{background:#24392e;padding:22px;border-radius:14px}</style></head><body><h1>Vitest · js-core-ersinbaev</h1>'''
    report += f'<div class="meta">npm test · {results["numPassedTests"]} passed / {results["numTotalTests"]} tests · {results["numFailedTests"]} failed<br>Источник: test-results.json — фактический запуск Vitest.</div>'
    report += ''.join(lines) + '</body></html>'
    (root / 'js-core-ersinbaev/screenshots/test-report.html').write_text(report, encoding='utf-8')
